# FarmConnect Website

A responsive frontend for a farmer-to-buyer marketplace.

## Technology
- HTML5, CSS3, JavaScript and Bootstrap 5
- Language selector: English, Marathi and Hindi
- Fruit and vegetable photo gallery on the home page
- Sign-up and sign-in flow for accounts created by the user in the same browser

## Run
1. Extract the `FarmConnect` folder.
2. Open the folder in VS Code.
3. Start the **Live Server** extension and open `index.html` through its localhost address.
4. An internet connection is needed for Bootstrap, Font Awesome, Google Fonts and the produce photos.

## Sign-up and sign-in
- Create an account using the Register page.
- Choose Farmer or Buyer.
- Sign in using the same email, password and account type.
- The browser stores the account locally and stores a salted PBKDF2 password hash.
- Accounts are not sent to a server and cannot be used on another browser or device. This is a frontend-only demonstration of the account flow, not production authentication.

## Pages
- Home, Products, Find Farmers, Login, Register
- Farmer, Buyer and Admin dashboards
- Requests, Availability Calendar, Chat, About and Contact

## Data and real-time limitations
- No seeded/demo accounts, sample farmer listings, fake prices, sample orders or fabricated chat messages are included.
- The marketplace starts empty. The fruit and vegetable photos on the home page are category illustrations only; they are not product listings.
- Sign-up and sign-in work locally in the current browser only.
- A frontend-only website cannot sync accounts, product listings, requests or chat between different users/devices in real time. That requires a shared backend or realtime service such as Firebase.
